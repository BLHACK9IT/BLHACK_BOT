# main.py

from src import TradingBot
from src.config import ACTIVE_CATEGORIES
from src.data import MultiAssetDataFetcher
from src.config import BROKER_API_CREDENTIALS

def main():
    # Just display options
    print("BROKER_API_CREDENTIALS keys:", list(BROKER_API_CREDENTIALS.keys()))
    print("Full config:", BROKER_API_CREDENTIALS)

    fetcher = MultiAssetDataFetcher()
    
    print(f"\nActive Categories: {ACTIVE_CATEGORIES}")
    print(f"Loaded Symbols: {list(fetcher.symbol_category_map.keys())}\n")
    
    # User input
    user_symbol = input("Enter symbol (e.g., EURUSD): ").strip()
    user_mode = input("Enter mode (scalping/day_trading/swing): ").strip()
    
    # Create bot (broker connection happens inside TradingBot)
    try:
        bot = TradingBot(symbol=user_symbol, mode=user_mode)
        bot.run_system_check()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()