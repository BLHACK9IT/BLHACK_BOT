import requests

api_token = "your_token_here"

response = requests.post(
    "https://api.deriv.com/api/v3",
    json={"authorize": api_token}
)

print("Status:", response.status_code)
print("Text:", response.text)
print("Headers:", response.headers)