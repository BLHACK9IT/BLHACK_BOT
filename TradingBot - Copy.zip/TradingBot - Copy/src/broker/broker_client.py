# src/broker/deriv_client.py

"""
Deriv WebSocket API Client for reading account details.
Uses new WebSocket-based API: wss://ws.derivws.com/websockets/v3
"""

import json
import asyncio
import websockets
from typing import Dict, Optional
 


class DerivClient:
    """
    WebSocket client for Deriv API.
    Reads account balance and details from paper trading account.
    """
    
    WS_URL = "wss://api.derivws.com/trading/v1/options/ws/demo"
    
    def __init__(self, api_token: str, app_id: str = "1089"):
        """
        Initialize Deriv WebSocket client.
        
        Parameters
        ----------
        api_token : str
            API token from Deriv account (from .env)
        app_id : str
            Deriv app ID (default: 1089 for testing)
        """
        self.api_token = api_token      # Use parameter
        self.app_id = app_id            # Use parameter
        self.websocket = None
        self.account_details = None
        self._connect()
    
    def _connect(self):
        """Connect to Deriv WebSocket API."""
        try:
            # Run async connection in sync context
            asyncio.run(self._async_connect())
        except Exception as e:
            raise ConnectionError(f"Failed to connect to Deriv: {str(e)}")
    
    async def _async_connect(self):
        """Async WebSocket connection."""
        try:
            url = f"{self.WS_URL}?app_id={self.app_id}"
            self.websocket = await websockets.connect(url)
        
            # Authorize with token AND app_id
            auth_request = {
                "authorize": self.api_token
                # "app_id": self.app_id
            }
        
            await self.websocket.send(json.dumps(auth_request))
            response = await self.websocket.recv()
            data = json.loads(response)
        
            if "error" in data:
                raise ValueError(f"Auth failed: {data['error']['message']}")
        
            print("✓ Connected to Deriv WebSocket API")
        
        except Exception as e:
            raise ConnectionError(f"WebSocket connection failed: {str(e)}")
    
    def get_account_details(self) -> Dict:
        """
        Fetch real account details from Deriv.
        
        Returns
        -------
        dict
            {
                "balance": float,
                "currency": str,
                "account_type": str,
                "is_virtual": bool,
            }
        """
        try:
            # Run async fetch in sync context
            return asyncio.run(self._async_get_account_details())
        except Exception as e:
            raise RuntimeError(f"Failed to fetch account details: {str(e)}")
    
    async def _async_get_account_details(self) -> Dict:
        """Async account details fetch."""
        try:
            # Request account balance
            balance_request = {
                "balance": 1,
                "subscribe": 1
            }
            
            await self.websocket.send(json.dumps(balance_request))
            response = await self.websocket.recv()
            data = json.loads(response)
            
            if "error" in data:
                raise ValueError(f"Balance fetch failed: {data['error']['message']}")
            
            balance_data = data.get("balance", {})
            
            account_details = {
                "balance": float(balance_data.get("balance", 0)),
                "currency": balance_data.get("currency", "USD"),
                "account_id": balance_data.get("loginid", ""),
                "account_type": "virtual",  # Paper trading
                "is_virtual": True,
            }
            
            self.account_details = account_details
            return account_details
            
        except Exception as e:
            raise RuntimeError(f"Account details fetch failed: {str(e)}")
    
    def validate_connection(self) -> bool:
        """
        Test if connection is valid.
        
        Returns
        -------
        bool
            True if connected, False otherwise
        """
        try:
            details = self.get_account_details()
            return details.get("balance") is not None
        except Exception as e:
            print(f"Connection validation failed: {str(e)}")
            return False
    
    async def _async_close(self):
        """Async close connection."""
        if self.websocket:
            await self.websocket.close()
    
    def close(self):
        """Close WebSocket connection."""
        try:
            asyncio.run(self._async_close())
        except Exception as e:
            print(f"Warning: Error closing connection: {str(e)}")
    
    def __del__(self):
        """Cleanup on delete."""
        self.close()